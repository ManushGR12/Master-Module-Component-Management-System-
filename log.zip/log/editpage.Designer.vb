﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class editpage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(editpage))
        Panel2 = New Panel()
        Panel1 = New Panel()
        PictureBox3 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        Label2 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        PictureBox5 = New PictureBox()
        PictureBox11 = New PictureBox()
        PictureBox12 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox2 = New PictureBox()
        Label13 = New Label()
        Label6 = New Label()
        Label14 = New Label()
        DateTimePicker1 = New DateTimePicker()
        Label15 = New Label()
        DataGridView1 = New DataGridView()
        RadioButton1 = New RadioButton()
        RadioButton2 = New RadioButton()
        Button2 = New Button()
        Button1 = New Button()
        Label7 = New Label()
        Label9 = New Label()
        Timer1 = New Timer(components)
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.OldLace
        Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), Image)
        Panel2.BackgroundImageLayout = ImageLayout.Stretch
        Panel2.Controls.Add(Panel1)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Location = New Point(2, -8)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(355, 1076)
        Panel2.TabIndex = 4
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ButtonHighlight
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(PictureBox3)
        Panel1.Controls.Add(PictureBox10)
        Panel1.Controls.Add(PictureBox9)
        Panel1.Controls.Add(PictureBox8)
        Panel1.Controls.Add(PictureBox7)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(PictureBox5)
        Panel1.Controls.Add(PictureBox11)
        Panel1.Controls.Add(PictureBox12)
        Panel1.Controls.Add(PictureBox6)
        Panel1.Location = New Point(28, 158)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(296, 714)
        Panel1.TabIndex = 18
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(84, 42)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(127, 122)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 18
        PictureBox3.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(30, 533)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(73, 62)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 38
        PictureBox10.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(30, 451)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(68, 62)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 37
        PictureBox9.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), Image)
        PictureBox8.Location = New Point(30, 372)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(73, 62)
        PictureBox8.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox8.TabIndex = 36
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), Image)
        PictureBox7.Location = New Point(43, 300)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(55, 50)
        PictureBox7.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox7.TabIndex = 35
        PictureBox7.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Romantic", 13.8F)
        Label2.ForeColor = SystemColors.ActiveCaptionText
        Label2.Location = New Point(117, 314)
        Label2.Name = "Label2"
        Label2.Size = New Size(69, 26)
        Label2.TabIndex = 29
        Label2.Text = "Home"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Romantic", 13.8F)
        Label5.ForeColor = SystemColors.ActiveCaptionText
        Label5.Location = New Point(119, 550)
        Label5.Name = "Label5"
        Label5.Size = New Size(71, 26)
        Label5.TabIndex = 31
        Label5.Text = "About"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Romantic", 13.8F)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(117, 473)
        Label4.Name = "Label4"
        Label4.Size = New Size(132, 26)
        Label4.TabIndex = 30
        Label4.Text = "Edit or View"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Romantic", 13.8F)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(113, 379)
        Label3.Name = "Label3"
        Label3.Size = New Size(130, 52)
        Label3.TabIndex = 29
        Label3.Text = "Add New " & vbCrLf & "Components"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Romantic", 13.8F)
        Label1.ForeColor = SystemColors.ActiveCaptionText
        Label1.Location = New Point(113, 210)
        Label1.Name = "Label1"
        Label1.Size = New Size(77, 26)
        Label1.TabIndex = 28
        Label1.Text = "Admin"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.BorderStyle = BorderStyle.FixedSingle
        PictureBox5.Location = New Point(-3, 295)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(299, 70)
        PictureBox5.TabIndex = 2
        PictureBox5.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.BackColor = Color.Transparent
        PictureBox11.BorderStyle = BorderStyle.FixedSingle
        PictureBox11.Location = New Point(-5, 447)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(299, 70)
        PictureBox11.TabIndex = 33
        PictureBox11.TabStop = False
        ' 
        ' PictureBox12
        ' 
        PictureBox12.BackColor = Color.Transparent
        PictureBox12.BorderStyle = BorderStyle.FixedSingle
        PictureBox12.Location = New Point(-5, 523)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(299, 80)
        PictureBox12.TabIndex = 34
        PictureBox12.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BorderStyle = BorderStyle.FixedSingle
        PictureBox6.Location = New Point(-4, 371)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(299, 70)
        PictureBox6.TabIndex = 32
        PictureBox6.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(49, 927)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(258, 50)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 17
        PictureBox2.TabStop = False
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label13.ForeColor = SystemColors.ActiveCaptionText
        Label13.Location = New Point(1694, 237)
        Label13.Name = "Label13"
        Label13.Size = New Size(0, 34)
        Label13.TabIndex = 37
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label6.ForeColor = SystemColors.ActiveCaptionText
        Label6.Location = New Point(400, 34)
        Label6.Name = "Label6"
        Label6.Size = New Size(168, 34)
        Label6.TabIndex = 44
        Label6.Text = "Edit or View"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label14.ForeColor = SystemColors.ActiveCaptionText
        Label14.Location = New Point(1542, 47)
        Label14.Name = "Label14"
        Label14.Size = New Size(71, 34)
        Label14.TabIndex = 45
        Label14.Text = "Date"
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.CalendarMonthBackground = Color.LightSkyBlue
        DateTimePicker1.Location = New Point(1642, 53)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(250, 27)
        DateTimePicker1.TabIndex = 46
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label15.ForeColor = SystemColors.ActiveCaptionText
        Label15.Location = New Point(1642, 175)
        Label15.Name = "Label15"
        Label15.Size = New Size(176, 34)
        Label15.TabIndex = 47
        Label15.Text = "Return Status"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = SystemColors.Control
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(363, 104)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(1213, 892)
        DataGridView1.TabIndex = 48
        ' 
        ' RadioButton1
        ' 
        RadioButton1.AutoSize = True
        RadioButton1.Font = New Font("Romantic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        RadioButton1.Location = New Point(1694, 291)
        RadioButton1.Name = "RadioButton1"
        RadioButton1.Size = New Size(69, 30)
        RadioButton1.TabIndex = 49
        RadioButton1.TabStop = True
        RadioButton1.Text = "Yes"
        RadioButton1.UseVisualStyleBackColor = True
        ' 
        ' RadioButton2
        ' 
        RadioButton2.AutoSize = True
        RadioButton2.Font = New Font("Romantic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        RadioButton2.Location = New Point(1694, 340)
        RadioButton2.Name = "RadioButton2"
        RadioButton2.Size = New Size(62, 30)
        RadioButton2.TabIndex = 50
        RadioButton2.TabStop = True
        RadioButton2.Text = "No"
        RadioButton2.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
        Button2.BackgroundImageLayout = ImageLayout.Zoom
        Button2.Location = New Point(1642, 536)
        Button2.Name = "Button2"
        Button2.Size = New Size(192, 44)
        Button2.TabIndex = 52
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
        Button1.BackgroundImageLayout = ImageLayout.Zoom
        Button1.Location = New Point(1642, 459)
        Button1.Name = "Button1"
        Button1.Size = New Size(192, 54)
        Button1.TabIndex = 51
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label7.ForeColor = SystemColors.ActiveCaptionText
        Label7.Location = New Point(1658, 646)
        Label7.Name = "Label7"
        Label7.Size = New Size(190, 34)
        Label7.TabIndex = 53
        Label7.Text = "Date and Time"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label9.ForeColor = SystemColors.ActiveCaptionText
        Label9.Location = New Point(1658, 701)
        Label9.Name = "Label9"
        Label9.Size = New Size(30, 34)
        Label9.TabIndex = 55
        Label9.Text = "*"
        ' 
        ' Timer1
        ' 
        ' 
        ' editpage
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1924, 1055)
        Controls.Add(Label9)
        Controls.Add(Label7)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(RadioButton2)
        Controls.Add(RadioButton1)
        Controls.Add(DataGridView1)
        Controls.Add(Label15)
        Controls.Add(DateTimePicker1)
        Controls.Add(Label14)
        Controls.Add(Label6)
        Controls.Add(Label13)
        Controls.Add(Panel2)
        Name = "editpage"
        Text = "editpage"
        WindowState = FormWindowState.Maximized
        Panel2.ResumeLayout(False)
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label15 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Timer1 As Timer
End Class
