﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class additem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(additem))
        Panel2 = New Panel()
        Panel1 = New Panel()
        Button1 = New Button()
        Label1 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Panel5 = New Panel()
        Label6 = New Label()
        Button6 = New Button()
        Panel3 = New Panel()
        Button8 = New Button()
        Label8 = New Label()
        Panel7 = New Panel()
        PictureBox3 = New PictureBox()
        Label10 = New Label()
        Panel6 = New Panel()
        Label7 = New Label()
        Button7 = New Button()
        Label9 = New Label()
        Timer1 = New Timer(components)
        Label12 = New Label()
        Panel4 = New Panel()
        Label15 = New Label()
        PictureBox6 = New PictureBox()
        TextBox4 = New TextBox()
        Label14 = New Label()
        TextBox3 = New TextBox()
        Label13 = New Label()
        PictureBox5 = New PictureBox()
        PictureBox4 = New PictureBox()
        Label11 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label2 = New Label()
        DataGridView1 = New DataGridView()
        Button2 = New Button()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel5.SuspendLayout()
        Panel3.SuspendLayout()
        Panel7.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel6.SuspendLayout()
        Panel4.SuspendLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.Transparent
        Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), Image)
        Panel2.BackgroundImageLayout = ImageLayout.Stretch
        Panel2.Controls.Add(Panel1)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Controls.Add(Panel5)
        Panel2.Location = New Point(1, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(250, 1076)
        Panel2.TabIndex = 30
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Transparent
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(0, 558)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(250, 196)
        Panel1.TabIndex = 28
        ' 
        ' Button1
        ' 
        Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
        Button1.BackgroundImageLayout = ImageLayout.Zoom
        Button1.Location = New Point(67, 12)
        Button1.Name = "Button1"
        Button1.Size = New Size(96, 87)
        Button1.TabIndex = 19
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label1.Location = New Point(58, 111)
        Label1.Name = "Label1"
        Label1.Size = New Size(133, 72)
        Label1.TabIndex = 18
        Label1.Text = "View Items " & vbCrLf & "      or" & vbCrLf & "  Delete"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(89, 872)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(80, 85)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 17
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(89, 80)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(80, 74)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 3
        PictureBox1.TabStop = False
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.Transparent
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Label6)
        Panel5.Controls.Add(Button6)
        Panel5.Location = New Point(0, 236)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(250, 162)
        Panel5.TabIndex = 27
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label6.Location = New Point(67, 118)
        Label6.Name = "Label6"
        Label6.Size = New Size(116, 24)
        Label6.TabIndex = 22
        Label6.Text = "Add Items"
        ' 
        ' Button6
        ' 
        Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), Image)
        Button6.BackgroundImageLayout = ImageLayout.Stretch
        Button6.Location = New Point(82, 22)
        Button6.Name = "Button6"
        Button6.Size = New Size(89, 81)
        Button6.TabIndex = 21
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.Thistle
        Panel3.Controls.Add(Button8)
        Panel3.Controls.Add(Label8)
        Panel3.Location = New Point(1, 125)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(250, 157)
        Panel3.TabIndex = 31
        ' 
        ' Button8
        ' 
        Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), Image)
        Button8.BackgroundImageLayout = ImageLayout.Zoom
        Button8.Location = New Point(67, 12)
        Button8.Name = "Button8"
        Button8.Size = New Size(96, 87)
        Button8.TabIndex = 19
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label8.Location = New Point(56, 111)
        Label8.Name = "Label8"
        Label8.Size = New Size(124, 24)
        Label8.TabIndex = 18
        Label8.Text = "View Users"
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = Color.Thistle
        Panel7.Controls.Add(PictureBox3)
        Panel7.Controls.Add(Label10)
        Panel7.Location = New Point(1, 666)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(250, 157)
        Panel7.TabIndex = 33
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(76, 15)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(80, 73)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 25
        PictureBox3.TabStop = False
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label10.Location = New Point(56, 100)
        Label10.Name = "Label10"
        Label10.Size = New Size(135, 48)
        Label10.TabIndex = 24
        Label10.Text = "Enter New " & vbCrLf & "Components"
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.Thistle
        Panel6.Controls.Add(Label7)
        Panel6.Controls.Add(Button7)
        Panel6.Location = New Point(1, 491)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(250, 157)
        Panel6.TabIndex = 32
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label7.Location = New Point(56, 100)
        Label7.Name = "Label7"
        Label7.Size = New Size(138, 48)
        Label7.TabIndex = 24
        Label7.Text = "Edit or View" & vbCrLf & "Components"
        ' 
        ' Button7
        ' 
        Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), Image)
        Button7.BackgroundImageLayout = ImageLayout.Stretch
        Button7.Location = New Point(80, 15)
        Button7.Name = "Button7"
        Button7.Size = New Size(92, 79)
        Button7.TabIndex = 23
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(1007, 519)
        Label9.Name = "Label9"
        Label9.Size = New Size(0, 42)
        Label9.TabIndex = 40
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 1000
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(259, 708)
        Label12.Name = "Label12"
        Label12.Size = New Size(174, 42)
        Label12.TabIndex = 43
        Label12.Text = "Save Items"
        ' 
        ' Panel4
        ' 
        Panel4.Controls.Add(Label15)
        Panel4.Controls.Add(PictureBox6)
        Panel4.Controls.Add(TextBox4)
        Panel4.Controls.Add(Label14)
        Panel4.Controls.Add(TextBox3)
        Panel4.Controls.Add(Label13)
        Panel4.Controls.Add(PictureBox5)
        Panel4.Controls.Add(Label12)
        Panel4.Controls.Add(PictureBox4)
        Panel4.Controls.Add(Label11)
        Panel4.Controls.Add(Label5)
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(Label3)
        Panel4.Controls.Add(TextBox2)
        Panel4.Controls.Add(TextBox1)
        Panel4.Location = New Point(390, 125)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(1068, 808)
        Panel4.TabIndex = 44
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(657, 708)
        Label15.Name = "Label15"
        Label15.Size = New Size(90, 42)
        Label15.TabIndex = 59
        Label15.Text = "Clear"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), Image)
        PictureBox6.Location = New Point(657, 592)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(80, 85)
        PictureBox6.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox6.TabIndex = 58
        PictureBox6.TabStop = False
        ' 
        ' TextBox4
        ' 
        TextBox4.Font = New Font("Romantic", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox4.Location = New Point(72, 395)
        TextBox4.Multiline = True
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(175, 46)
        TextBox4.TabIndex = 57
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(72, 337)
        Label14.Name = "Label14"
        Label14.Size = New Size(137, 42)
        Label14.TabIndex = 56
        Label14.Text = "Quantity"
        ' 
        ' TextBox3
        ' 
        TextBox3.Font = New Font("Romantic", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox3.Location = New Point(779, 515)
        TextBox3.Multiline = True
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(175, 46)
        TextBox3.TabIndex = 55
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(761, 441)
        Label13.Name = "Label13"
        Label13.Size = New Size(193, 42)
        Label13.TabIndex = 54
        Label13.Text = "Insert image"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(722, 178)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(275, 215)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 53
        PictureBox5.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(302, 592)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(80, 85)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 52
        PictureBox4.TabStop = False
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("ISOCPEUR", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(430, 461)
        Label11.Name = "Label11"
        Label11.Size = New Size(30, 36)
        Label11.TabIndex = 51
        Label11.Text = "*"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(78, 461)
        Label5.Name = "Label5"
        Label5.Size = New Size(228, 42)
        Label5.TabIndex = 50
        Label5.Text = "Date And Time"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(453, 195)
        Label4.Name = "Label4"
        Label4.Size = New Size(126, 42)
        Label4.TabIndex = 49
        Label4.Text = "Item No"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("ISOCPEUR", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(72, 195)
        Label3.Name = "Label3"
        Label3.Size = New Size(163, 42)
        Label3.TabIndex = 48
        Label3.Text = "Item Name"
        ' 
        ' TextBox2
        ' 
        TextBox2.Font = New Font("Romantic", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox2.Location = New Point(430, 264)
        TextBox2.Multiline = True
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(175, 46)
        TextBox2.TabIndex = 47
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Romantic", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox1.Location = New Point(72, 264)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(175, 46)
        TextBox1.TabIndex = 46
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("ISOCPEUR", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(793, 50)
        Label2.Name = "Label2"
        Label2.Size = New Size(187, 50)
        Label2.TabIndex = 45
        Label2.Text = "Add Items"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.BackgroundColor = SystemColors.Control
        DataGridView1.BorderStyle = BorderStyle.Fixed3D
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(403, 135)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(816, 558)
        DataGridView1.TabIndex = 46
        ' 
        ' Button2
        ' 
        Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
        Button2.BackgroundImageLayout = ImageLayout.Zoom
        Button2.Location = New Point(793, 781)
        Button2.Name = "Button2"
        Button2.Size = New Size(276, 66)
        Button2.TabIndex = 48
        Button2.UseVisualStyleBackColor = True
        ' 
        ' additem
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1717, 1055)
        Controls.Add(Panel4)
        Controls.Add(Label9)
        Controls.Add(Panel2)
        Controls.Add(Panel3)
        Controls.Add(Panel7)
        Controls.Add(Panel6)
        Controls.Add(Label2)
        Controls.Add(DataGridView1)
        Controls.Add(Button2)
        Name = "additem"
        Text = "additem"
        WindowState = FormWindowState.Maximized
        Panel2.ResumeLayout(False)
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend Protected WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Button2 As Button
End Class
