﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Panel2 = New Panel()
        Panel1 = New Panel()
        PictureBox3 = New PictureBox()
        PictureBox10 = New PictureBox()
        PictureBox9 = New PictureBox()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        Label2 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        PictureBox5 = New PictureBox()
        PictureBox11 = New PictureBox()
        PictureBox12 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label6 = New Label()
        Label8 = New Label()
        ComboBox1 = New ComboBox()
        ComboBox2 = New ComboBox()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        ComboBox4 = New ComboBox()
        Label13 = New Label()
        Label14 = New Label()
        Timer1 = New Timer(components)
        PictureBox4 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        Label7 = New Label()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.OldLace
        Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), Image)
        Panel2.BackgroundImageLayout = ImageLayout.Stretch
        Panel2.Controls.Add(Panel1)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Location = New Point(-2, -2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(355, 1076)
        Panel2.TabIndex = 3
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ButtonHighlight
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(PictureBox3)
        Panel1.Controls.Add(PictureBox10)
        Panel1.Controls.Add(PictureBox9)
        Panel1.Controls.Add(PictureBox8)
        Panel1.Controls.Add(PictureBox7)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(Label5)
        Panel1.Controls.Add(Label4)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(PictureBox5)
        Panel1.Controls.Add(PictureBox11)
        Panel1.Controls.Add(PictureBox12)
        Panel1.Controls.Add(PictureBox6)
        Panel1.Location = New Point(28, 158)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(296, 714)
        Panel1.TabIndex = 18
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(84, 42)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(127, 122)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 18
        PictureBox3.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(30, 533)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(73, 62)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 38
        PictureBox10.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(30, 451)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(68, 62)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 37
        PictureBox9.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), Image)
        PictureBox8.Location = New Point(30, 372)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(73, 62)
        PictureBox8.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox8.TabIndex = 36
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), Image)
        PictureBox7.Location = New Point(43, 300)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(55, 50)
        PictureBox7.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox7.TabIndex = 35
        PictureBox7.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Romantic", 13.8F)
        Label2.ForeColor = SystemColors.ActiveCaptionText
        Label2.Location = New Point(117, 314)
        Label2.Name = "Label2"
        Label2.Size = New Size(69, 26)
        Label2.TabIndex = 29
        Label2.Text = "Home"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Romantic", 13.8F)
        Label5.ForeColor = SystemColors.ActiveCaptionText
        Label5.Location = New Point(119, 550)
        Label5.Name = "Label5"
        Label5.Size = New Size(71, 26)
        Label5.TabIndex = 31
        Label5.Text = "About"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Romantic", 13.8F)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(117, 473)
        Label4.Name = "Label4"
        Label4.Size = New Size(132, 26)
        Label4.TabIndex = 30
        Label4.Text = "Edit or View"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Romantic", 13.8F)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(113, 379)
        Label3.Name = "Label3"
        Label3.Size = New Size(130, 52)
        Label3.TabIndex = 29
        Label3.Text = "Add New " & vbCrLf & "Components"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Romantic", 13.8F)
        Label1.ForeColor = SystemColors.ActiveCaptionText
        Label1.Location = New Point(113, 210)
        Label1.Name = "Label1"
        Label1.Size = New Size(77, 26)
        Label1.TabIndex = 28
        Label1.Text = "Admin"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.BorderStyle = BorderStyle.FixedSingle
        PictureBox5.Location = New Point(-3, 295)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(299, 70)
        PictureBox5.TabIndex = 2
        PictureBox5.TabStop = False
        ' 
        ' PictureBox11
        ' 
        PictureBox11.BackColor = Color.Transparent
        PictureBox11.BorderStyle = BorderStyle.FixedSingle
        PictureBox11.Location = New Point(-1, 447)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(297, 70)
        PictureBox11.TabIndex = 33
        PictureBox11.TabStop = False
        ' 
        ' PictureBox12
        ' 
        PictureBox12.BackColor = Color.Transparent
        PictureBox12.BorderStyle = BorderStyle.FixedSingle
        PictureBox12.Location = New Point(-1, 525)
        PictureBox12.Name = "PictureBox12"
        PictureBox12.Size = New Size(296, 80)
        PictureBox12.TabIndex = 34
        PictureBox12.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.BorderStyle = BorderStyle.FixedSingle
        PictureBox6.Location = New Point(-1, 371)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(299, 70)
        PictureBox6.TabIndex = 32
        PictureBox6.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.BorderStyle = BorderStyle.FixedSingle
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(49, 927)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(258, 50)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 17
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(1712, 44)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(146, 42)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 3
        PictureBox1.TabStop = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label6.ForeColor = SystemColors.ActiveCaptionText
        Label6.Location = New Point(418, 44)
        Label6.Name = "Label6"
        Label6.Size = New Size(88, 34)
        Label6.TabIndex = 29
        Label6.Text = "Home"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label8.ForeColor = SystemColors.ActiveCaptionText
        Label8.Location = New Point(456, 223)
        Label8.Name = "Label8"
        Label8.Size = New Size(147, 34)
        Label8.TabIndex = 31
        Label8.Text = "Item Name"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.Font = New Font("Romantic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(657, 223)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(151, 34)
        ComboBox1.TabIndex = 32
        ' 
        ' ComboBox2
        ' 
        ComboBox2.Font = New Font("Romantic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(657, 311)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(151, 34)
        ComboBox2.TabIndex = 34
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label10.ForeColor = SystemColors.ActiveCaptionText
        Label10.Location = New Point(1100, 223)
        Label10.Name = "Label10"
        Label10.Size = New Size(86, 34)
        Label10.TabIndex = 37
        Label10.Text = "Name"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label11.ForeColor = SystemColors.ActiveCaptionText
        Label11.Location = New Point(1100, 311)
        Label11.Name = "Label11"
        Label11.Size = New Size(97, 34)
        Label11.TabIndex = 38
        Label11.Text = "Ref ID"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label12.ForeColor = SystemColors.ActiveCaptionText
        Label12.Location = New Point(1100, 408)
        Label12.Name = "Label12"
        Label12.Size = New Size(155, 34)
        Label12.TabIndex = 39
        Label12.Text = "Department"
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Romantic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox1.Location = New Point(1337, 220)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(441, 38)
        TextBox1.TabIndex = 40
        ' 
        ' TextBox2
        ' 
        TextBox2.Font = New Font("Romantic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        TextBox2.Location = New Point(1337, 307)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(441, 38)
        TextBox2.TabIndex = 41
        ' 
        ' ComboBox4
        ' 
        ComboBox4.Font = New Font("Romantic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        ComboBox4.FormattingEnabled = True
        ComboBox4.Items.AddRange(New Object() {"BCA", "BBA", "B.com", "LLB", "Others"})
        ComboBox4.Location = New Point(1337, 404)
        ComboBox4.Name = "ComboBox4"
        ComboBox4.Size = New Size(441, 38)
        ComboBox4.TabIndex = 42
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label13.ForeColor = SystemColors.ActiveCaptionText
        Label13.Location = New Point(456, 428)
        Label13.Name = "Label13"
        Label13.Size = New Size(190, 34)
        Label13.TabIndex = 43
        Label13.Text = "Date and Time"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label14.ForeColor = SystemColors.ActiveCaptionText
        Label14.Location = New Point(690, 428)
        Label14.Name = "Label14"
        Label14.Size = New Size(30, 34)
        Label14.TabIndex = 44
        Label14.Text = "*"
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 1000
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Location = New Point(581, 604)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(343, 224)
        PictureBox4.TabIndex = 45
        PictureBox4.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
        Button1.BackgroundImageLayout = ImageLayout.Zoom
        Button1.Location = New Point(1449, 660)
        Button1.Name = "Button1"
        Button1.Size = New Size(192, 54)
        Button1.TabIndex = 46
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
        Button2.BackgroundImageLayout = ImageLayout.Zoom
        Button2.Location = New Point(1449, 737)
        Button2.Name = "Button2"
        Button2.Size = New Size(192, 44)
        Button2.TabIndex = 47
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Romantic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(2))
        Label7.ForeColor = SystemColors.ActiveCaptionText
        Label7.Location = New Point(456, 311)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 34)
        Label7.TabIndex = 48
        Label7.Text = "Item No"
        ' 
        ' Home
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1924, 1055)
        Controls.Add(Label7)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(PictureBox4)
        Controls.Add(Label14)
        Controls.Add(Label13)
        Controls.Add(ComboBox4)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(ComboBox2)
        Controls.Add(ComboBox1)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Panel2)
        Controls.Add(PictureBox1)
        Name = "Home"
        Text = "Home"
        WindowState = FormWindowState.Maximized
        Panel2.ResumeLayout(False)
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox12, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label7 As Label
End Class
