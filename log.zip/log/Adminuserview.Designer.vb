﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Adminuserview
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Adminuserview))
        Label1 = New Label()
        Label9 = New Label()
        Panel4 = New Panel()
        PictureBox8 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox4 = New PictureBox()
        Label14 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        PictureBox5 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        PictureBox3 = New PictureBox()
        Panel4.SuspendLayout()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("PanRoman", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label1.Location = New Point(837, 80)
        Label1.Name = "Label1"
        Label1.Size = New Size(48, 60)
        Label1.TabIndex = 21
        Label1.Text = "*"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("PanRoman", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label9.Location = New Point(837, 140)
        Label9.Name = "Label9"
        Label9.Size = New Size(498, 60)
        Label9.TabIndex = 28
        Label9.Text = "Select Your Action"
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.LightSteelBlue
        Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), Image)
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(PictureBox8)
        Panel4.Controls.Add(PictureBox7)
        Panel4.Controls.Add(PictureBox6)
        Panel4.Controls.Add(PictureBox4)
        Panel4.Controls.Add(Label14)
        Panel4.Controls.Add(Label11)
        Panel4.Controls.Add(Label12)
        Panel4.Controls.Add(Label13)
        Panel4.Location = New Point(504, 224)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(966, 547)
        Panel4.TabIndex = 29
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), Image)
        PictureBox8.Location = New Point(121, 166)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(93, 96)
        PictureBox8.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox8.TabIndex = 30
        PictureBox8.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), Image)
        PictureBox7.Location = New Point(577, 166)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(93, 96)
        PictureBox7.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox7.TabIndex = 29
        PictureBox7.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), Image)
        PictureBox6.Location = New Point(347, 166)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(93, 96)
        PictureBox6.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox6.TabIndex = 28
        PictureBox6.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = Color.Transparent
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(778, 155)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(93, 96)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 27
        PictureBox4.TabStop = False
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.BackColor = Color.Transparent
        Label14.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label14.Location = New Point(800, 294)
        Label14.Name = "Label14"
        Label14.Size = New Size(71, 24)
        Label14.TabIndex = 26
        Label14.Text = "About"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.BackColor = Color.Transparent
        Label11.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label11.Location = New Point(563, 294)
        Label11.Name = "Label11"
        Label11.Size = New Size(138, 24)
        Label11.TabIndex = 13
        Label11.Text = "Edit or View" & vbCrLf
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.BackColor = Color.Transparent
        Label12.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label12.Location = New Point(332, 294)
        Label12.Name = "Label12"
        Label12.Size = New Size(142, 48)
        Label12.TabIndex = 12
        Label12.Text = "Add New " & vbCrLf & " Components"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.BackColor = Color.Transparent
        Label13.Font = New Font("PanRoman", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, CByte(2))
        Label13.Location = New Point(145, 294)
        Label13.Name = "Label13"
        Label13.Size = New Size(69, 24)
        Label13.TabIndex = 11
        Label13.Text = "Home"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(994, 864)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(80, 73)
        PictureBox5.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox5.TabIndex = 30
        PictureBox5.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(0, -4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(368, 327)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 31
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(0, 753)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(311, 257)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 32
        PictureBox1.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(1822, 281)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(129, 547)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 33
        PictureBox3.TabStop = False
        ' 
        ' Adminuserview
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1924, 1004)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox5)
        Controls.Add(Panel4)
        Controls.Add(Label9)
        Controls.Add(Label1)
        Name = "Adminuserview"
        Text = "Adminuserview"
        WindowState = FormWindowState.Maximized
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
End Class
